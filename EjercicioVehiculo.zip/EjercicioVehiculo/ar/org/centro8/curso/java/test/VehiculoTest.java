package Ejercicioauto.ar.org.centro8.curso.java.test;
import Ejercicioauto.ar.org.centro8.curso.java.entities.VehiculoClasico;
import Ejercicioauto.ar.org.centro8.curso.java.entities.VehiculoNuevo;

public class VehiculoTest {

    public static void main(String[] args)
    
    {   
       //Vehiculo clasico con radio all
        System.out.println( "----------------Vehiculo clasico con radio-------------------------");
        VehiculoClasico vcr = new VehiculoClasico("peugeo", "206", "red", 20000, "Colgate");
        System.out.println(vcr.toString());

        //Vehiculo clasi sin radio,all
        System.out.println("----------------Vehiculo  clasico  sin radio-------------------------------------");
        VehiculoClasico vc=new VehiculoClasico("Audi", "01", "gris", 5000);
        System.out.println(vc.toString());

      // clasi con radio y sin precio
      System.out.println("------------- clasi con radio y sin precio----------------------------------------"); 
      VehiculoClasico vrsp = new VehiculoClasico("Rexona", "Aunca te abandona", "negro", 0, "Argentina");
      System.out.println(vrsp.toString());
        
      //Vehiculo nuevo sin radio sin precio
        System.out.println( "----------------Nuevo sin radio sin precio-------------------------");
        VehiculoNuevo vcrp = new VehiculoNuevo("Dord", "focus", "verde");
        System.out.println(vcrp.toString());


      //Vehiculo nuevo con radio y precio
        System.out.println("-------------Vehiculo nuevo con radio y precio----------------------------------------"); 
        VehiculoNuevo vn=new VehiculoNuevo("Fiat", "02", "verde", 20000, "Phillips");
        System.out.println(vn.toString());
      
   
    
      }
    
}