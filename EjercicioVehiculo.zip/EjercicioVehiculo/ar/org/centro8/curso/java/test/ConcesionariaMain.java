/*--------------------La solucion debe cumplir con los siguientes requisitos :---------------------

 - Diseñar una solucion orientada a objetos , creando por lo menos una clase abstracta
 - La salida es por consola y exactamente como se requiere
 . Sobreescribir el metodo toString 
 - Usar solamente las clases provistar por java 8
 - Cargar la lista de autos en un unico metodo . No hay ingreso por pantalla de ningun tipo
 . El algoritmo usado para la impresion no tiene que depender de la cantidad , modelo o tipo de autos 
 - el entregable debera ser la URL de un repositorio Git publico para que podamos descargar directamente
  */

/*  ------------------------- Concesionaria De Autos  ----------------------------------------------

  Crear un programa cuyo punto de entrada  sea un main en donde , al ejecutarse ,se visualiza lo
  siguiente por consola y se  termina  la ejecucion :
 
  Marca Peugeot, Modelo 206  , Puertas 4    ,  Cilindrada Null , Precio 200.000.00
  Marca Honda  , Modelo Titan, Puertas Null ,  Cilindrada 125  , Precio 60.000.00
  Marca Peugeot, Modelo 208  , Puertas 5    ,  Cilindrada Null , Precio 250.000.00
  Marca Yamaha , Modelo YBR  , Puertas Null ,  Cilindrada 160c , Precio 80.500.50
  ---------------------------------------------------------------------------------
  Vehiculo mas caro : Peugeot 208
  Vehiculo mas Barato : Honda Titan 
  Vehiculo que contiene  en el modelo la letra ´Y´: Yamaha YBR $80.500.00
  ---------------------------------------------------------------------------------
  Vehiculos ordenados por precion mayor a menor :
  Peugeot 208
  Peugeot 206
  Yamaha  YBR
  Honda   Titan
  ---------------------------------------------------------------------------------
  Vehiculos ordenados por orden Natural :
  Marca Honda  , Modelo Titan, Puertas Null ,  Cilindrada 125  , Precio 60.000.00
  Marca Peugeot, Modelo 206  , Puertas 4    ,  Cilindrada Null , Precio 200.000.00
  Marca Peugeot, Modelo 208  , Puertas 5    ,  Cilindrada Null , Precio 250.000.00  
  Marca Yamaha , Modelo YBR  , Puertas Null ,  Cilindrada 160c , Precio 80.500.50
 */ 
package Ejercicioauto.ar.org.centro8.curso.java.test;

import Ejercicioauto.ar.org.centro8.curso.java.Concecionaria.Honda;
import Ejercicioauto.ar.org.centro8.curso.java.Concecionaria.Peugeot;
import Ejercicioauto.ar.org.centro8.curso.java.Concecionaria.Peugeot2;
import Ejercicioauto.ar.org.centro8.curso.java.Concecionaria.Yamaha;

public class ConcesionariaMain {

public static void main(String[] args) 
{

    System.out.println("----------------------------------------------------------------------------------------------");
    Peugeot  p1=new Peugeot("Peugeot", "206", "4", 200.000);
    System.out.println(p1.toString());   

    System.out.println("----------------------------------------------------------------------------------------------"); 
    Honda    h1=new Honda("Honda", "Titan", 60.000, "125c");
    System.out.println(h1.toString());

    System.out.println("----------------------------------------------------------------------------------------------");
    Peugeot2 p2 = new Peugeot2("Peugeot", "208", "5", 250.000);
    System.out.println(p2.toString());

    System.out.println("----------------------------------------------------------------------------------------------");
    Yamaha   ym =new Yamaha("Yamaha", "YBR", 80.500, "160c");
    System.out.println(ym.toString());


//--------------------------------------------------------------------------------------------------





}





    
}
