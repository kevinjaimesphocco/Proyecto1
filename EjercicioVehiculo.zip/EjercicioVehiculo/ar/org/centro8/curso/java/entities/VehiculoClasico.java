package Ejercicioauto.ar.org.centro8.curso.java.entities;

public class VehiculoClasico extends Vehiculo{

  // sin precio sin radio
    public VehiculoClasico(String marca, String modelo, String color) {
      super(marca, modelo, color);
    }

  // sin precio sin radio
    public VehiculoClasico(String marca, String modelo, String color, double precio) {
      super(marca, modelo, color, precio);

    }
    
// precio y con radio
    public VehiculoClasico(String marca, String modelo, String color, double precio, String marcaRadio) {
      super(marca, modelo, color, precio, marcaRadio);
    }
     
   // con radio sin precio
    public VehiculoClasico(String marca, String modelo, String color, String marcaRadio) {
      super(marca, modelo, color, marcaRadio);
    }

    @Override
    public String toString() {
      return "VehiculoClasico []"+super.toString();
    }


   


   

    
}