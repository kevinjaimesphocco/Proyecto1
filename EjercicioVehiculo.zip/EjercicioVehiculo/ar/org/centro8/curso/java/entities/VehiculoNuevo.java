package Ejercicioauto.ar.org.centro8.curso.java.entities;

public class VehiculoNuevo extends Vehiculo{

    private Radio radio;
    // con precio y con radio
    public VehiculoNuevo(String marca, String modelo, String color, double precio, String marcaRadio) {
        super(marca, modelo, color, precio, marcaRadio);
        this.radio=new Radio(marcaRadio);
    }
         // sin radio sin precio
    public VehiculoNuevo(String marca, String modelo, String color) {
        super(marca, modelo, color);
    }

    @Override
    public String toString() {
        return "VehiculoNuevo [radio=" + radio + "]"+super.toString();
    }



/*@Override
    public String toString() {
        return "VehiculoNuevo" + super.toString() + "\nradio=" + radio;
    } */
    

    
    
}